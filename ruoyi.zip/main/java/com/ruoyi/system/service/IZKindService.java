package com.ruoyi.system.service;

import java.util.List;
import com.ruoyi.system.domain.ZKind;

/**
 * 【请填写功能名称】Service接口
 * 
 * @author ruoyi
 * @date 2024-06-11
 */
public interface IZKindService 
{
    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    public ZKind selectZKindById(Long id);

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param zKind 【请填写功能名称】
     * @return 【请填写功能名称】集合
     */
    public List<ZKind> selectZKindList(ZKind zKind);

    /**
     * 新增【请填写功能名称】
     * 
     * @param zKind 【请填写功能名称】
     * @return 结果
     */
    public int insertZKind(ZKind zKind);

    /**
     * 修改【请填写功能名称】
     * 
     * @param zKind 【请填写功能名称】
     * @return 结果
     */
    public int updateZKind(ZKind zKind);

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键集合
     * @return 结果
     */
    public int deleteZKindByIds(String ids);

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    public int deleteZKindById(Long id);
}
