package com.ruoyi.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.system.mapper.ZKindMapper;
import com.ruoyi.system.domain.ZKind;
import com.ruoyi.system.service.IZKindService;
import com.ruoyi.common.core.text.Convert;

/**
 * 【请填写功能名称】Service业务层处理
 * 
 * @author ruoyi
 * @date 2024-06-11
 */
@Service
public class ZKindServiceImpl implements IZKindService 
{
    @Autowired
    private ZKindMapper zKindMapper;

    /**
     * 查询【请填写功能名称】
     * 
     * @param id 【请填写功能名称】主键
     * @return 【请填写功能名称】
     */
    @Override
    public ZKind selectZKindById(Long id)
    {
        return zKindMapper.selectZKindById(id);
    }

    /**
     * 查询【请填写功能名称】列表
     * 
     * @param zKind 【请填写功能名称】
     * @return 【请填写功能名称】
     */
    @Override
    public List<ZKind> selectZKindList(ZKind zKind)
    {
        return zKindMapper.selectZKindList(zKind);
    }

    /**
     * 新增【请填写功能名称】
     * 
     * @param zKind 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int insertZKind(ZKind zKind)
    {
        return zKindMapper.insertZKind(zKind);
    }

    /**
     * 修改【请填写功能名称】
     * 
     * @param zKind 【请填写功能名称】
     * @return 结果
     */
    @Override
    public int updateZKind(ZKind zKind)
    {
        return zKindMapper.updateZKind(zKind);
    }

    /**
     * 批量删除【请填写功能名称】
     * 
     * @param ids 需要删除的【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteZKindByIds(String ids)
    {
        return zKindMapper.deleteZKindByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除【请填写功能名称】信息
     * 
     * @param id 【请填写功能名称】主键
     * @return 结果
     */
    @Override
    public int deleteZKindById(Long id)
    {
        return zKindMapper.deleteZKindById(id);
    }
}
